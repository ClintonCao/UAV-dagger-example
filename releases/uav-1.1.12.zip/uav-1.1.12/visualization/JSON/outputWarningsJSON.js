var inputData = 
[
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "default",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.warnings",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.groupers",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.computers",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.finders",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.gui",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "SomePackage.different",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.writers",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.uav",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.summarizers",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "SomePackage.subpackage",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  },
  {
    "classes": [],
    "numberOfClasses": 0,
    "packageName": "BlueTurtle.parsers",
    "numberOfWarnings": 0,
    "warningTypes": [],
    "numberOfCheckStyleWarnings": 0,
    "numberOfPMDWarnings": 0,
    "numberOfFindBugsWarnings": 0
  }
];
var projectName = "test";